
export default function HomePage() {
  return (
    <div style={{ fontFamily: 'Arial', padding: '2rem' }}>
      <h1>The United States Times</h1>
      <p>Welcome to your AI-powered, multilingual news platform.</p>
    </div>
  );
}
